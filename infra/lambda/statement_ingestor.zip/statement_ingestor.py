def ingest_statement(event, context):
    # Logic to handle HTTP or S3 trigger
    print("Hello World")

    return {"statusCode": 200, "body": "Success"}

